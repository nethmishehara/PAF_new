import React, { useEffect, useState } from 'react';
import { getAllUsers } from '../../services/api';

function ConnectionsList() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    getAllUsers().then(res => setUsers(res.data));
  }, []);

  return (
    <div>
      <h3>Connections</h3>
      <ul>
        {users.map(user => (
          <li key={user.id}>{user.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default ConnectionsList;