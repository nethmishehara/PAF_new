import React, { useEffect, useState } from 'react';
import { getUserById } from '../../services/api';
import ProfileEditModal from './ProfileEditModal';
import RecommendedCourses from './RecommendedCourses';
import ConnectionsList from './ConnectionsList';
import './Profile.css';

function Profile() {
  const [user, setUser] = useState(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    getUserById('user123')
      .then((res) => setUser(res.data))
      .catch((err) => console.error(err));
  }, []);

  if (!user) return <div>Loading...</div>;

  return (
    <div className="profile-container">
      <div className="profile-header">
        <h1>{user.name}</h1>
        <p>{user.bio}</p>
        <button onClick={() => setShowModal(true)}>Edit Profile</button>
      </div>

      <div className="profile-skills">
        <h3>Skills</h3>
        <ul>
          {user.skills.map((skill, idx) => <li key={idx}>{skill}</li>)}
        </ul>
      </div>

      <RecommendedCourses userId={user.id} />
      <ConnectionsList />
      {showModal && <ProfileEditModal user={user} onClose={() => setShowModal(false)} setUser={setUser} />}
    </div>
  );
}

export default Profile;