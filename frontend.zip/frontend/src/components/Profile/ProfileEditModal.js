import React, { useState } from 'react';
import { updateUser } from '../../services/api';
import './ProfileEditModal.css';

function ProfileEditModal({ user, onClose, setUser }) {
  const [skills, setSkills] = useState(user.skills.join(', '));

  const handleSave = () => {
    const updated = { ...user, skills: skills.split(',').map(s => s.trim()) };
    updateUser(user.id, updated)
      .then((res) => {
        setUser(res.data);
        onClose();
      });
  };

  return (
    <div className="modal">
      <div className="modal-content">
        <h2>Edit Skills</h2>
        <textarea value={skills} onChange={(e) => setSkills(e.target.value)} />
        <button onClick={handleSave}>Save</button>
        <button onClick={onClose}>Cancel</button>
      </div>
    </div>
  );
}

export default ProfileEditModal;
