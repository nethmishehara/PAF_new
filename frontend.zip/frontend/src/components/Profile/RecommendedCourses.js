import React, { useEffect, useState } from 'react';
import { getRecommendedCourses } from '../../services/api';

function RecommendedCourses({ userId }) {
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    getRecommendedCourses(userId)
      .then(res => setCourses(res.data))
      .catch(err => console.error(err));
  }, [userId]);

  return (
    <div>
      <h3>Recommended Courses</h3>
      <ul>
        {courses.map(course => (
          <li key={course.id}>{course.title}</li>
        ))}
      </ul>
    </div>
  );
}

export default RecommendedCourses;