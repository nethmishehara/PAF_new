import React, { useState } from 'react';
import { likePost } from '../../services/api';
import CommentSection from './CommentSection';

const PostItem = ({ post, userId }) => {
  const [likes, setLikes] = useState(post.likes.length);

  const handleLike = () => {
    likePost(post.id, userId).then((res) => setLikes(res.data.likes.length));
  };

  return (
    <div className="post-item">
      <p>{post.content}</p>
      <button onClick={handleLike}>Like ({likes})</button>
      <CommentSection postId={post.id} userId={userId} />
    </div>
  );
};

export default PostItem;
