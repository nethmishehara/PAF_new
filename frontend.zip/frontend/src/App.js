// App.js
import React from 'react';
import Profile from './components/Profile/Profile'; // Ensure the path is correct
import Header from './components/Shared/Header';
import NotificationList from './components/Notification/NotificationList';
import PostList from './components/Posts/PostList'; // Ensure the path is correct
import './App.css';

function App() {
  const userId = 'user123'; // Replace with dynamic user ID if available

  return (
    <div className="App">
      <Header />
      <Profile />
      <NotificationList userId={userId} />
      <PostList userId={userId} />
    </div>
  );
}

export default App; // Ensure the default export is correct
