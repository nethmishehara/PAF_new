import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:8080/api',
});

export const getUserById = (id) => api.get(`/users/${id}`);
export const updateUser = (id, user) => api.put(`/users/${id}`, user);
export const getRecommendedCourses = (id) => api.get(`/courses/recommend/${id}`);
export const getAllUsers = () => api.get('/users');


export const fetchPosts = () => api.get('/posts');
export const createPost = (post) => api.post('/posts', post);
export const likePost = (postId, userId) => api.post(`/posts/${postId}/like`, null, { params: { userId } });
export const addComment = (comment) => api.post('/comments', comment);
export const editComment = (id, text) => api.put(`/comments/${id}`, text, { headers: { 'Content-Type': 'text/plain' } });
export const deleteComment = (id, userId) => api.delete(`/comments/${id}`, { params: { userId } });
export const fetchNotifications = (userId) => api.get(`/notifications/${userId}`);
export default api;

